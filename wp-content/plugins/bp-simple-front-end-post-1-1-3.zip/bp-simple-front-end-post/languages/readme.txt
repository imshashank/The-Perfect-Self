Please use a language translator to translate the included languages.po file. I recommend poedit for the translations.
Save the generated mo file as your_Local.mo, e.g (en_US.mo or fr_FR.mo)
