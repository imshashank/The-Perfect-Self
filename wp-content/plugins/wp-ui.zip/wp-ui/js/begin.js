// var jqOrig = jQuery.noConflict( true );
var jQueryOriginal = jQuery;

