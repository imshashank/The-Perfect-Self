// var newJQ = jqOrig.noConflict();

window.jQuery = jQueryOriginal;