<div class="gdsr">
<div class="wrap"><h2 class="gdptlogopage">GD Star Rating 2.0 Update Information</h2>
    <p>GD Star Rating 2.0 is currently in development. Public Alpha #2 version will be released on June 20 2012.<br/>To get more information about GD Star Rating 2.0, you can follow one of these links:</p>
    <ul>
        <li>Development on Dev4Press: <a target="_blank" href="http://www.dev4press.com/category/blog/development/gdsr2/">GDSR2 Development Blog</a></li>
        <li>Plugin home on Dev4Press: <a target="_blank" href="http://www.dev4press.com/plugins/gd-star-rating/">GD Star Rating</a></li>
    </ul>
    <p>GD Star Rating 2.0 is not compatible with GD Star Rating 1.9.x. Final version of GDSR 2.0 will include tools<br/>to convert data from old format to new one. But, any code written for old plugin will not work with new one.</p>
</div></div>