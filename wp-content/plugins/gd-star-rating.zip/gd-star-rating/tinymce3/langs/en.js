tinyMCE.addI18n({en:{
StarRating:{	
desc : 'Add StarRating Shortcodes'
}}});
