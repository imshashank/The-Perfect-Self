=== BP Posts On Profile ===
Contributors: hberberoglu
Tags: buddypress, profile, posts, show posts on profile, wordpress mu, bp, extend profile 
Requires at least: WordPress 2.9.1, BuddyPress 1.2.3
Tested up to: WordPress 2.9.2 / BuddyPress 1.2.3
Stable tag: 1.0

Adds 'Posts' link to member's profile page, and shows member's blog posts on that page.

== Description ==

Adds 'Posts' link to member's profile page, and shows member's blog posts on that page.

== Installation ==

Download and upload the plugin to your plugins folder. You can activate it to test the BP Posts On Profile it provides.
