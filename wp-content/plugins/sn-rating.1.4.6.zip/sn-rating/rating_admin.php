<?php
/**
 * 
 * This would be a singleton class having all kinds of admin stuff required at various places
 * like when we store the data to dbase.
 * @author dkum32
 *
 */
class RatingAdmin {
  
}