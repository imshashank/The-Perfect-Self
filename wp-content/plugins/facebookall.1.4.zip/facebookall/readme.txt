=== Facebook All ===
Contributors: sourceaddons, patrykos360 (Language translator - polish)
Tags: Facebook Login, Facebook Connect, Social Login, Social Share, facebook fanbox, facebook comments, facebook facepile, Facebook Login For Wordpress, facebook all, facebook social plugins, Facebook Analytics, Facebook, Google Login, Google Login For Wordpress, Google Connect
Requires at least: 3.0
Tested up to: 3.5.1
Stable tag: 1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Make your blog fully social with facebook social plugins and allow your visitor to comment and login with Facebook and Google.
== Description ==



The Facebook All Plugin is a collection of facebook social plugins for Wordpress. that allows your visitors to comment, 
login and register with social networks Facebook and google. 
<strong>Make your blog social!</strong><br />

<strong>Its includes:</strong>

<ul>
 <li>Google Login(Premium Feature)</li><li>Facebook Analytics(Premium Feature)</li><li>Woocommerce compatible(Premium Feature)</li><li>Available in Languages (German, Polish)</li><li>Facebook Login</li><li>Facebook Fanbox</li> <li>Facebook Facepile</li><li>Facebook Comments</li><li>Facebook Recommendations Bar</li><li>Social Sharing</li></ul>


<strong>Features:</strong>

<ul>
 <li>Choose where to show facebook login.</li><li>optioally redirect user after login.</li> <li>User friendly admin interface</li><li>Easy to configure</li><li>Rich profile data</li><li>Buddypress compatible</li><li>All faceook socialplugins in one pack</li><li>Fully customizable facebook icon</li><li>Many more...</li></ul>
For Demo :- <a href="http://wp.sourceaddons.com/">FacebookAll Demo</a>
This plugin is maintained by sourceaddons. for any tech support or any customization please contact <a href="http://www.sourceaddons.com">sourceaddons</a> or write a email to us on sourceaddons@ymail.com 

== Installation ==

= Install Upgrade version =


1. As admistration, Dectivate and delete the old installed plugin(facebookall) through the 'Plugins' menu in WordPress,

= Using upload =


1. Download, Unzip and drop the extention on /wp-content/plugins/ directory,

2. As admistration, activate the plugin through the 'Plugins' menu in WordPress,

3. Goto the Settings > Facebook All to get started.


= Using admin =


1. As admistration, goto 'Plugins' then Click on 'Add New',

2. Search for 'facebookall' then Click on 'Install Now',

3. Wait for it to download, Unpack and to install,

4. Activate the plugin by Clicking on 'Activate Plugin'

5. Goto the Settings > Facebook All to get started.
= Configuring the Widget =

1. Once you activate the plugin, go to the 'Widgets' section in the 'Design' or 'Appearance' menu.
2. Look for the 'facebookall' widget and click on the 'Add' link, or drag and drop the widget to the widget area on the right.
3. After adding the facebookall widget, customize it by changing the title, text show before, text show after, etc.

= Settings =

1. Go to 'Settings' section and click on 'Facebook All' option.
2. Create app on facebook Copy and Paste API Key and Secret in configuration.
= Short code for pages and posts =
Shortcode for FacebookAll Login: [facebookall_login]<br />
Shortcode for FacebookAll Sharing: [facebookall_share]<br />
Shortcode for FacebookAll Fanbox: [facebookall_fanbox]<br />
Shortcode for FacebookAll Facepile: [facebookall_facepile]<br />
Shortcode for FacebookAll Comments: [facebookall_comments]<br />

= Technical Support Questions =
Write a email to us on sourceaddons@ymail.com


== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==
1. This is an example presentation of login page with facebook login button.
2. displays admin area.
3. This is an example of Facebook Analytics in admin area.

== Changelog ==

= 1.0 =
* A intial version.

= 1.1 =
* Integrated with facebook app new changes.
* Redirect uri bug fixed.
* Added option for enable recommendations bar.
* share enhanced with post share.
* blank page show on login issue fixed.

= 1.2 =
* Facebook login popup enhanced.
* Recommendations bar bug fixed.
* Typo issue fixed in admin.
* premium features added :-
1. Facebook Analytics with charts.
2. Option for popup/same window redirection (Works in all browser).
3. Woocommerce compatible..
4. localization for facebook social plugins added.
5. Available in Languages (German, Polish)

= 1.3 =
* Recommendations bar bug fixed.
* Fixed widget conflict with theme.
* Fixed wall post settings bug.
* Added facebook share button.
* premium features added :-
1. Google Login added.
2. Option for choose language for facebook plugins.
3. Login icon enhanced.

= 1.4 =
* fixed content not appearing issue.


